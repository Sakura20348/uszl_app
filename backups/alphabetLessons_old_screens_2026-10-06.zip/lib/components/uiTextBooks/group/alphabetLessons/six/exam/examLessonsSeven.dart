import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:signlang/services/app_loading.dart';
import 'package:flutter/material.dart';
import 'package:signlang/components/uiTextBooks/group/alphabetLessons/six/exam/examLessonsEight.dart';
import 'package:video_player/video_player.dart';

import '../../../../../../l10n/app_localizations.dart';
import '../../../../../../main.dart';
import '../../../../../web/input/waveInput.dart';
import '../../../../../web/loading/bookLoading.dart';
import '../../../../nameTextbooks/nameTextbooks.dart';
import '../../alphabetOnboardingProgress.dart';

import 'package:signlang/services/theme_service.dart';
class ExamLessonsSeven5 extends StatefulWidget{
  const ExamLessonsSeven5({super.key});

  @override
  State<ExamLessonsSeven5> createState() => _ExamLessonsSeven5State();
}

class _ExamLessonsSeven5State extends State<ExamLessonsSeven5> {
  late VideoPlayerController _videoController;
  bool _isVideoInitialized = false;
  bool _isLoading = true;
  bool _isChecked = false;
  double _currentSpeed = 1.0;
  final TextEditingController _answerController = TextEditingController();
  static const String _correctAnswer = 'V';

  bool get _isCorrect => _answerController.text.trim().toUpperCase() == _correctAnswer;
  bool get _canCheck => _answerController.text.trim().isNotEmpty;

  @override
  void initState() { super.initState(); _initData(); _initializePlayer(); }

  @override
  void dispose() {
    _answerController.dispose();
    if (_isVideoInitialized) _videoController.dispose();
    super.dispose();
  }

// =======================================================================
  Future<void> _initializePlayer() async {
    _videoController = VideoPlayerController.asset('assets/videos/alphabet_fixed/level_V.mp4'); // video v
    try {
      await _videoController.initialize();
      await _videoController.setLooping(true);
      await _videoController.play();
      setState(() => _isVideoInitialized = true);
    } catch (e) { debugPrint("Video init error: $e"); }
  }

  Future<void> _initData() async { await AppLoading.ready(); if (mounted) { setState(() { _isLoading = false; }); } }
  Future<void> _handleRefresh() async { setState(() { _isLoading = true; }); await _initializeData(); }
  Future<void> _initializeData() async { final results = await Future.wait([AppLoading.ready()]); if (!mounted) return; setState(() { _isLoading = false; }); }

  // =======================================================================
  void _handleNext() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const ExamLessonsEight5()));
    setState(() { _isChecked = false; _answerController.clear(); });
  }

  void _showQuitDialog() {
    final loc = AppLocalizations.of(context)!;
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24), side: BorderSide(color: AppPalette.border(Colors.white), width: 1)), elevation: 15, backgroundColor: AppPalette.bg(Colors.white).withValues(alpha: 0.7),
        shadowColor: AppPalette.shadow(Color(0xFF42A5F5)).withValues(alpha: 0.9), title: Text(loc.translate('quit_lesson'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
        content: Text(loc.translate('quit_lesson_sub'), style: TextStyle(fontSize: 16, color: AppPalette.fg(Colors.grey[800]!))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(loc.translate('cancel'), style: TextStyle(fontSize: 16, color: AppPalette.fg(Colors.grey[700]!), fontWeight: FontWeight.w600))),
          ElevatedButton(
            onPressed: () { Navigator.pop(dialogContext); Navigator.pushAndRemoveUntil(context, _slideLeftRoute(const MainWrapper(initialTab: 0)), (route) => false); },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppPalette.bg(Color(0xFFEF9A9A)).withValues(alpha: 0.2), foregroundColor: AppPalette.fg(Colors.white), elevation: 6, shadowColor: AppPalette.shadow(Color(0xFFB71C1C)).withValues(alpha: 0.9),
              side: BorderSide(width: 1, color: AppPalette.border(Color(0xFFB71C1C)).withValues(alpha: 0.2)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))
            ),
            child: Text(loc.translate('quit'), style: TextStyle(fontSize: 16, color: AppPalette.fg(Colors.red[900]!), fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Route _slideLeftRoute(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionsBuilder: (_, animation, __, child) {
        final tween = Tween(begin: const Offset(-1, 0), end: Offset.zero).chain(CurveTween(curve: Curves.easeInOut));
        return SlideTransition(position: animation.drive(tween), child: child);
      },
      transitionDuration: const Duration(milliseconds: 300),
    );
  }

  @override
  Widget build(BuildContext context){
    return PopScope(
      canPop: false, onPopInvokedWithResult: (didPop, result) { if (didPop) return; _showQuitDialog(); },
      child: Scaffold(
        body: Container(
          width: double.infinity, decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [AppPalette.bg(Color(0xFFBBDEFB)), AppPalette.bg(Colors.white)])),
          child: SafeArea(
            child: RefreshIndicator(
              onRefresh: _handleRefresh, notificationPredicate: (ScrollNotification notification) {return notification.depth == 0;},
              child: CustomScrollView(
                slivers: [
                  if (_isLoading)
                    const SliverFillRemaining(hasScrollBody: false, child: Center(child: BookLoader(label: 'Loading')))
                  else
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                        child: Stack(
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // ===== 1) back =====
                                GestureDetector(
                                  onTap: () => _showQuitDialog(),
                                  child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppPalette.bg(Colors.white), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.close))
                                ),
                                const SizedBox(height: 20),
                                // ===== 2) text and line =====
                                SizedBox(
                                  width: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Text('6/7', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w400, color: AppPalette.fg(Colors.grey[700]!))),
                                      const SizedBox(height: 4), const ExamAlphabetOnboardingProgress(currentStep: 5)
                                    ]
                                  )
                                ),
                                const SizedBox(height: 16),
                                // ===== 2) video =====
                                Container(
                                  width: double.infinity, height: MediaQuery.of(context).size.height * 0.34, decoration: BoxDecoration(color: AppPalette.bg(Colors.white), borderRadius: BorderRadius.circular(24)), clipBehavior: Clip.antiAlias,
                                  child: _isVideoInitialized ? AspectRatio(aspectRatio: _videoController.value.aspectRatio, child: VideoPlayer(_videoController)) : const Center(child: CircularProgressIndicator()),
                                ),
                                const SizedBox(height: 10),
                                // ===== 3) cards =====
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    _buildVideoAction(Icons.refresh, AppLocalizations.of(context)!.translate('again'), () => _videoController.seekTo(Duration.zero)),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: DropdownButtonHideUnderline(
                                        child: DropdownButton2<double>(
                                          customButton: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                                            decoration: BoxDecoration(color: AppPalette.bg(Colors.white).withValues(alpha: 0.6), borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: AppPalette.shadow(Colors.grey).withValues(alpha: 0.9), blurRadius: 12)]),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Icon(Icons.speed, size: 16, color: AppPalette.fg(Colors.black54)), const SizedBox(width: 6),
                                                Text("${_currentSpeed}x", style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppPalette.fg(Colors.black)))
                                              ]
                                            )
                                          ),
                                          items: [0.5, 1.0, 1.5].map<DropdownMenuItem<double>>((double speed) {
                                            final isWeight = (_currentSpeed - speed).abs() < 0.01 ? FontWeight.bold : FontWeight.normal;
                                            final Color isColor = (_currentSpeed - speed).abs() < 0.01 ? AppPalette.auto(Color(0xFF4A7FD0)) : AppPalette.auto(Colors.black87);
                                            return DropdownMenuItem<double>(value: speed, child: Center(child: Text("${speed}x", style: TextStyle(fontSize: 15, fontWeight: isWeight, color: isColor))));
                                          }).toList(),
                                          value: _currentSpeed,
                                          onChanged: (double? newSpeed) { if (newSpeed != null) { setState(() { _currentSpeed = newSpeed; }); if (_isVideoInitialized) { _videoController.setPlaybackSpeed(_currentSpeed); } } },
                                          dropdownStyleData: DropdownStyleData(width: 60, decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: AppPalette.bg(Colors.white)), offset: const Offset(0, -8)),
                                          menuItemStyleData: const MenuItemStyleData(height: 38, padding: EdgeInsets.symmetric(horizontal: 14))
                                        )
                                      )
                                    ),
                                    const SizedBox(width: 10),
                                    _buildVideoAction(Icons.call_made, AppLocalizations.of(context)!.translate('corner'), () {})
                                  ]
                                ),
                                const SizedBox(height: 16),
                                // ===== 4) text =====
                                Text(AppLocalizations.of(context)!.translate('what_name'), style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppPalette.fg(Color(0xFF0F172A)))),
                                const SizedBox(height: 16),
                                Center(child: WaveInput(label: 'Level', controller: _answerController, onChanged: (_) => setState(() {}))),
                                const SizedBox(height: 36),
                                const Spacer(),
                                // ===== 5) button =====
                                _buildBottomButton(context)
                              ]
                            ),
                            if (_isChecked) ...[Positioned(left: 0, right: 0, bottom: 80, child: _buildFeedbackBanner(context, _isCorrect))]
                          ]
                        )
                      )
                    )
                ]
              )
            )
          )
        )
      )
    );
  }
  // ======================== build ========================
  Widget _buildVideoAction(IconData icon, String text, VoidCallback onTap) {
    return InkWell(
      onTap: onTap, borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 5),
        decoration: BoxDecoration(color: AppPalette.bg(Colors.white).withValues(alpha: 0.6), borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: AppPalette.shadow(Colors.grey).withValues(alpha: 0.8), blurRadius: 12)]),
        child: Row(children: [Icon(icon, size: 16, color: AppPalette.fg(Colors.black54)), const SizedBox(width: 6), Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600))])
      )
    );
  }

  // ===== green/red feedback banner shown after checking =====
  Widget _buildFeedbackBanner(BuildContext context, bool isCorrect) {
    final Color bg = isCorrect ? AppPalette.auto(Color(0xFFDCFCE7)) : AppPalette.auto(Color(0xFFFEE2E2));
    final Color fg = isCorrect ? AppPalette.auto(Color(0xFF16A34A)).withValues(alpha: 0.8) : AppPalette.auto(Color(0xFFDC2626)).withValues(alpha: 0.8);
    final Color sc = isCorrect ? AppPalette.auto(Color(0xFF16A34A)).withValues(alpha: 0.9) : AppPalette.auto(Color(0xFFDC2626)).withValues(alpha: 0.9);
    final String correctLabel = _correctAnswer.toUpperCase();  // "V"

    return Container(
      width: double.infinity, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: sc, blurRadius: 15)]),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(isCorrect ? Icons.check_circle : Icons.cancel, color: fg, size: 20),
          const SizedBox(width: 10),
          Expanded(
            child: isCorrect
              ? Text(AppLocalizations.of(context)!.translate('answer_correct'), style: TextStyle(color: fg, fontSize: 15, fontWeight: FontWeight.w600))
              : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(AppLocalizations.of(context)!.translate('answer_wrong'), style: TextStyle(color: fg, fontSize: 15, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text('${AppLocalizations.of(context)!.translate('correct_answer')}: $correctLabel', style: TextStyle(color: fg, fontSize: 13, fontWeight: FontWeight.w400)),
                ],
              )
          ),
          Icon(Icons.flag_outlined, color: fg, size: 18),
        ],
      ),
    );
  }

  // ===== bottom button: "check answer" -> "next question" =====
  Widget _buildBottomButton(BuildContext context) {
    final bool isCorrect = _isCorrect;
    final bool canCheck = _canCheck;

    Color bg; Color fg; Color sc;
    if (!_isChecked) {
      bg = AppPalette.auto(Color(0xFF4A7FD0)).withValues(alpha: 0.15);
      fg = canCheck ? AppPalette.auto(Colors.blue[900]!) : AppPalette.auto(Colors.blue[700]!);
      sc = AppPalette.auto(Color(0xFFBBDEFB)).withValues(alpha: 0.9);
    } else if (isCorrect) {
      bg = AppPalette.auto(Color(0xFF4CAF50)).withValues(alpha: 0.2);
      fg = AppPalette.auto(Colors.white);
      sc = AppPalette.auto(Color(0xFF1B5E20)).withValues(alpha: 0.9);
    } else {
      bg = AppPalette.auto(Color(0xFFF44336)).withValues(alpha: 0.2);
      fg = AppPalette.auto(Colors.white);
      sc = AppPalette.auto(Color(0xFFB71C1C)).withValues(alpha: 0.9);
    }
    final String label = _isChecked ? AppLocalizations.of(context)!.translate('next_question') : AppLocalizations.of(context)!.translate('check_answer_btn');
    void handleCheck() { setState(() { _isChecked = true; if (_isCorrect) { LessonProgress.instance.addCorrect(); } else { LessonProgress.instance.addWrong(); } }); }

    return SizedBox(
      width: double.infinity, height: 56,
      child: ElevatedButton(
        onPressed: _isChecked ? _handleNext : (canCheck ? handleCheck : null),
        style: ElevatedButton.styleFrom(
          backgroundColor: bg, disabledBackgroundColor: AppPalette.bg(Color(0xFF4A7FD0)).withValues(alpha: 0.1), foregroundColor: fg, elevation: 6, shadowColor: sc,
          side: BorderSide(width: 1, color: AppPalette.border(Color(0xFF1A237E)).withValues(alpha: 0.2)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [Text(label, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: fg)), const SizedBox(width: 8), Icon(Icons.arrow_forward, size: 18, color: fg)]
        )
      )
    );
  }
}